# CallerRecon v1.7 — Defensive Spam-Call Intelligence

Local Flask + SQLite application for passive phone-call OSINT, case tracking, evidence preservation and analyst-reviewed provider complaints. **No hacking, active probing, harassment, automatic takedowns or identity attribution.** Displayed caller IDs may be spoofed.

## Install (Kali Linux)

```bash
sudo apt update && sudo apt install -y python3-venv
unzip spam-caller-recon-v1.7.zip
cd spam-caller-recon-v1.7
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5050/soc (localhost only).

## What's new

- `/soc`: SOC-style investigation overview, call timeline, top displayed numbers, case links, transcript keyword summaries and filtered SVG association graph.
- `/api/v17/graph?q=...&kind=...`: local filtered relationship intelligence; kinds: all, number, claim, indicator, reputation.
- `/api/v17/cases/<id>/transcript-signals`: analyst-reviewable heuristic transcript signals (urgency, payment requests, credentials, remote access, impersonation).
- `/api/v17/health`: integration status and version.
- Existing optional Twilio carrier lookup and local faster-whisper transcription remain from v1.6. No new external provider is queried automatically. Reputation lookups remain manual; don't interpret carrier metadata as the origin of a spoofed call.

## Upgrade

Back up v1.6 `investigations.db` and `evidence_files/` while the application is stopped, then copy both to the v1.7 directory before first launch. Keep the original copy. Schema initialization retains existing tables and creates missing ones. Never expose this local development server publicly.

## Validation

Run `python -m unittest discover -s tests -v` with dependencies installed. New tests are in `tests/test_v17.py`. Syntax and archive integrity checks do not substitute for browser testing.

## Limitations

Keyword matches are weak signals and may be false positives. A connection between numbers, claims, domains, or reputation providers is not proof of common ownership or perpetrator identity. Evidence files are not tamper-proof; keep originals separately. Verify consent and recording laws. Reporting is analyst-controlled.
