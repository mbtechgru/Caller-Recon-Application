/* Local SVG only; textContent prevents HTML injection from analyst data. */
(async function(){
const svg=document.getElementById('v17-network'),out=document.getElementById('graph-result');
const NS='http://www.w3.org/2000/svg';
function el(tag,attrs){const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);return e;}
async function load(){const params=new URLSearchParams({q:document.getElementById('q').value,kind:document.getElementById('kind').value});
try{const r=await fetch('/api/v17/graph?'+params);if(!r.ok)throw Error('Request failed');const g=await r.json();svg.replaceChildren();out.textContent=`${g.nodes.length} nodes · ${g.edges.length} associations (not identity attribution)`;
const nodes=g.nodes.slice(0,100),ids=new Set(nodes.map(n=>n.id));const positions=new Map();nodes.forEach((n,i)=>{const a=i*2.39996,rad=25+Math.sqrt(i)*34;positions.set(n.id,[500+Math.cos(a)*rad,220+Math.sin(a)*rad]);});
g.edges.filter(e=>ids.has(e.source)&&ids.has(e.target)).forEach(e=>{const a=positions.get(e.source),b=positions.get(e.target);svg.appendChild(el('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#71849a','stroke-opacity':'.45'}));});
nodes.forEach(n=>{const [x,y]=positions.get(n.id);const dot=el('circle',{cx:x,cy:y,r:7,fill:n.kind==='number'?'#38bdf8':n.kind==='indicator'?'#fb923c':'#a78bfa'});const title=el('title',{});title.textContent=n.kind+': '+n.label;dot.appendChild(title);svg.appendChild(dot);const label=el('text',{x:x+10,y:y+3,fill:'currentColor','font-size':'10'});label.textContent=n.label.slice(0,28);svg.appendChild(label);});
if(g.nodes.length>100)out.textContent+=' · first 100 displayed';}catch(err){out.textContent='Unable to load graph: '+err.message;}}
document.getElementById('refresh').addEventListener('click',load);load();})();