"use strict";
const ns='http://www.w3.org/2000/svg';
function el(tag,attrs={},text=''){const e=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(text)e.textContent=text;return e;}
async function load(){
 const [g,s]=await Promise.all([fetch('/api/graph').then(r=>r.json()),fetch('/api/summary').then(r=>r.json())]);
 document.getElementById('nodes').textContent=g.nodes.length;document.getElementById('links').textContent=g.edges.length;
 document.getElementById('clusters').textContent=s.potential_claim_clusters.length;
 const svg=document.getElementById('network');svg.replaceChildren();
 const count=g.nodes.length;if(!count){svg.append(el('text',{x:350,y:230,fill:'#94a3b8'},'Add calls to build a relationship graph'));}
 const pos={};g.nodes.slice(0,160).forEach((n,i)=>{const ring=Math.floor(i/22),within=i%22,angle=2*Math.PI*within/Math.min(22,count-ring*22);const radius=85+ring*58;pos[n.id]={x:500+radius*Math.cos(angle),y:235+radius*Math.sin(angle)};});
 g.edges.forEach(edge=>{if(!pos[edge.source]||!pos[edge.target])return;svg.append(el('line',{x1:pos[edge.source].x,y1:pos[edge.source].y,x2:pos[edge.target].x,y2:pos[edge.target].y,stroke:'#64748b','stroke-opacity':'.45','stroke-width':1.5}));});
 g.nodes.slice(0,160).forEach(n=>{const p=pos[n.id],colors={number:'#38bdf8',claim:'#a78bfa',indicator:'#fb923c'};const group=el('g');group.append(el('circle',{cx:p.x,cy:p.y,r:n.kind==='number'?11:8,fill:colors[n.kind]||'#fff',stroke:'#0f172a','stroke-width':2}));group.append(el('title',{},n.kind+': '+n.label));group.append(el('text',{x:p.x+13,y:p.y+4,fill:'#e2e8f0','font-size':11},n.label.slice(0,24)));svg.append(group);});
 if(count>160){svg.append(el('text',{x:25,y:450,fill:'#fbbf24'},'Showing first 160 nodes; export JSON for complete graph.'));}
 const canvas=document.getElementById('trend'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#152239';ctx.fillRect(0,0,w,h);
 const days=s.daily.slice(-24),max=Math.max(1,...days.map(x=>x.calls));ctx.fillStyle='#38bdf8';days.forEach((d,i)=>{const bar=(w-60)/Math.max(1,days.length);const bh=d.calls/max*(h-80);ctx.fillRect(40+i*bar,h-35-bh,Math.max(3,bar-4),bh);if(i%Math.max(1,Math.ceil(days.length/6))===0){ctx.fillStyle='#cbd5e1';ctx.font='12px sans-serif';ctx.fillText(d.date.slice(5),40+i*bar,h-12);ctx.fillStyle='#38bdf8';}});
 const out=document.getElementById('campaigns');out.replaceChildren();if(!s.potential_claim_clusters.length){out.textContent='No shared caller-claim clusters across multiple numbers yet.';}else{s.potential_claim_clusters.forEach(c=>{const p=document.createElement('p');p.textContent=c.claim_cluster+' — '+c.distinct_numbers+' distinct numbers ('+c.numbers.join(', ')+')';out.append(p);});}
}
load().catch(()=>{document.getElementById('campaigns').textContent='Unable to load graph data.';});