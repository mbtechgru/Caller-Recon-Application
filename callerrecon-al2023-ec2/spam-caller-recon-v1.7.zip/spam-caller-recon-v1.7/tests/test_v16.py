import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import app

class NewFeatures(unittest.TestCase):
    def test_offline_analysis(self):
        self.assertTrue(app.analyze('+12025550123')['normalized'].startswith('+1'))
    def test_integrity_empty_case(self):
        with TemporaryDirectory() as d:
            with patch.object(app, 'DB', str(Path(d)/'db.sqlite')):
                app.init_db()
                with app.connect() as db:
                    db.execute("INSERT INTO cases (title,created_at) VALUES ('Test','now')")
                self.assertEqual(app.evidence_integrity(1), [])

if __name__ == '__main__': unittest.main()
