import os, tempfile, unittest
import app as module
class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=module.DB;module.DB=os.path.join(self.tmp.name,'test.db');module.init_db();self.client=module.app.test_client()
    def tearDown(self):module.DB=self.old;self.tmp.cleanup()
    def test_graph_empty(self):
        r=self.client.get('/api/graph');self.assertEqual(r.status_code,200);self.assertEqual(r.json['nodes'],[])
    def test_log_cluster_and_export(self):
        for n in ('+12025550101','+12025550102'):
            self.assertEqual(self.client.post('/add',data={'number':n,'called_at':'2026-10-17T11:30','label':'Fake bank security'}).status_code,302)
        s=self.client.get('/api/summary').json;self.assertEqual(len(s['potential_claim_clusters']),1)
        self.assertEqual(len(self.client.get('/export.json').json['calls']),2)
    def test_indicator(self):
        self.client.post('/indicators',data={'number':'+12025550101','kind':'domain','value':'example.org','confidence':'unverified'})
        self.assertEqual(len(self.client.get('/api/indicators').json),1)
    def test_no_automatic_api(self):
        r=self.client.get('/lookup?number=%2B12025550101');self.assertEqual(r.status_code,200)
if __name__=='__main__':unittest.main()
