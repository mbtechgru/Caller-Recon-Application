import os, tempfile, unittest
import app as module
class IntelligenceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.old=module.DB; module.DB=os.path.join(self.tmp.name,'test.db');module.init_db();self.client=module.app.test_client();self.client.get('/')
  self.token=self.client.get_cookie('callerrecon_csrf').value
 def tearDown(self): module.DB=self.old;self.tmp.cleanup()
 def post(self,path,data): return self.client.post(path,data={**data,'_csrf':self.token})
 def test_reputation_and_scoring(self):
  number='+12025550101'
  for _ in range(3): self.assertEqual(self.post('/add',{'number':number,'called_at':'2026-10-17T11:30'}).status_code,302)
  self.assertEqual(self.post('/reputation',{'number':number,'provider':'Community source','assessment':'spam'}).status_code,302)
  data=self.client.get('/api/intelligence').json['numbers'];self.assertEqual(data[0]['score'],40)
  self.assertEqual(len(self.client.get('/export.json').json['reputation']),1)
 def test_reject_invalid_reputation(self):
  self.assertEqual(self.post('/reputation',{'number':'123','provider':'test','assessment':'invalid'}).status_code,400)
 def test_csrf(self):
  self.assertEqual(self.client.post('/reputation',data={'number':'123'}).status_code,403)
if __name__=='__main__': unittest.main()
