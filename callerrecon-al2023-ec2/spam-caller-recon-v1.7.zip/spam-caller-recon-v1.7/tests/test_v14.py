import unittest
import app
class TestV14(unittest.TestCase):
    def test_campaign_endpoint(self):
        r=app.app.test_client().get('/api/campaigns')
        self.assertEqual(r.status_code,200)
        self.assertIn('campaigns',r.get_json())
    def test_dashboard(self):
        r=app.app.test_client().get('/threat-dashboard')
        self.assertEqual(r.status_code,200)
