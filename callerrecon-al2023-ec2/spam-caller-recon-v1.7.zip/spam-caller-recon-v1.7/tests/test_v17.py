import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app as target

class V17Tests(unittest.TestCase):
    def test_transcript_signals(self):
        x=target.transcript_signals('Act now! Buy a gift card and tell us your verification code.')
        kinds={s['category'] for s in x}
        self.assertTrue({'urgency','payment request','credential request'} <= kinds)
    def test_no_signal(self):
        self.assertEqual(target.transcript_signals('Hello, this is a reminder.'),[])
    def test_health(self):
        with target.app.test_client() as client:
            self.assertEqual(client.get('/api/v17/health').json['version'],'1.7')
    def test_filtered_graph(self):
        with target.app.test_client() as client:
            self.assertEqual(client.get('/api/v17/graph?kind=invalid').status_code,400)
            self.assertEqual(client.get('/api/v17/graph?kind=number').status_code,200)

if __name__=='__main__':unittest.main()
