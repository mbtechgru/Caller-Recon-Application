"""Local-only, passive spam-call investigation dashboard."""
import csv
import io
import os
import sqlite3
import json
import re
import urllib.request
import urllib.parse
import base64
import hashlib
import secrets
from pathlib import Path
from flask import send_file
from collections import defaultdict
from collections import Counter
from datetime import datetime, timezone
from flask import Flask, Response, abort, flash, redirect, render_template, request, url_for
import phonenumbers
from phonenumbers import carrier, geocoder, number_type, PhoneNumberType

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'investigations.db')
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'local-dev-change-me')
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024
EVIDENCE_DIR = Path(BASE) / 'evidence_files'
EVIDENCE_DIR.mkdir(exist_ok=True)
ALLOWED_EXT = {'.txt','.pdf','.png','.jpg','.jpeg','.wav','.mp3','.m4a','.eml'}

@app.before_request
def csrf_guard():
    if request.method == 'POST':
        expected = request.cookies.get('callerrecon_csrf')
        supplied = request.form.get('_csrf') or request.headers.get('X-CSRF-Token')
        if not expected or not supplied or not secrets.compare_digest(expected, supplied):
            abort(403)

@app.after_request
def csrf_cookie(response):
    if not request.cookies.get('callerrecon_csrf'):
        response.set_cookie('callerrecon_csrf', secrets.token_urlsafe(32), httponly=False, samesite='Strict', secure=request.is_secure)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Cache-Control'] = 'no-store'
    return response


def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS calls (
          id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL,
          called_at TEXT NOT NULL, label TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'manual',
          created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS cases (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS case_calls (case_id INTEGER NOT NULL, call_id INTEGER NOT NULL, PRIMARY KEY(case_id,call_id))''')
        db.execute('''CREATE TABLE IF NOT EXISTS attachments (id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER NOT NULL, created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS reputation (id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL, provider TEXT NOT NULL, assessment TEXT NOT NULL, report_count INTEGER, source_url TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', checked_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS transcripts (id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL, attachment_id INTEGER, transcript TEXT NOT NULL, engine TEXT NOT NULL, created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS provider_checks (id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL, provider TEXT NOT NULL, carrier TEXT NOT NULL, line_type TEXT NOT NULL, checked_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS indicators (
          id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL,
          kind TEXT NOT NULL, value TEXT NOT NULL, source_url TEXT NOT NULL DEFAULT '',
          confidence TEXT NOT NULL DEFAULT 'unverified', created_at TEXT NOT NULL)''')


        db.execute('''CREATE TABLE IF NOT EXISTS enrichment (
          id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL,
          normalized TEXT NOT NULL, valid INTEGER NOT NULL, region TEXT NOT NULL,
          carrier_hint TEXT NOT NULL, line_type_hint TEXT NOT NULL,
          checked_at TEXT NOT NULL, provenance TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS abuse_contacts (
          id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
          organization TEXT NOT NULL, role TEXT NOT NULL, contact_url TEXT NOT NULL,
          source_url TEXT NOT NULL, verified_at TEXT NOT NULL, verification_note TEXT NOT NULL)''')


def evidence_integrity(case_id):
    """Read original evidence bytes; compare size and digest with saved manifest."""
    with connect() as db:
        attachments = [dict(x) for x in db.execute(
            'SELECT * FROM attachments WHERE case_id=? ORDER BY id', (case_id,))]
    results = []
    for entry in attachments:
        name = entry['stored_name']
        target = EVIDENCE_DIR / name
        if Path(name).name != name or not target.is_file() or target.is_symlink():
            state, actual = 'missing_or_unsafe', None
        else:
            digest = hashlib.sha256()
            with target.open('rb') as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b''):
                    digest.update(chunk)
            actual = digest.hexdigest()
            state = 'verified' if actual == entry['sha256'] and target.stat().st_size == entry['size'] else 'mismatch'
        results.append({'id': entry['id'], 'filename': entry['original_name'],
                        'expected_sha256': entry['sha256'], 'actual_sha256': actual,
                        'status': state})
    return results


@app.route('/workspace')
def workspace():
    with connect() as db:
        cases = [dict(x) for x in db.execute('SELECT * FROM cases ORDER BY id DESC')]
        enrichment = [dict(x) for x in db.execute('SELECT * FROM enrichment ORDER BY id DESC LIMIT 30')]
    return render_template('workspace.html', cases=cases, enrichment=enrichment)


@app.post('/enrichment/local')
def enrichment_local():
    raw = request.form.get('number', '').strip()[:60]
    if not raw:
        abort(400)
    info = analyze(raw)
    now = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute('INSERT INTO enrichment (number, normalized, valid, region, carrier_hint, line_type_hint, checked_at, provenance) VALUES (?,?,?,?,?,?,?,?)',
                   (raw, info['normalized'], int(info['valid']), info['region'], info['carrier'], info['type'], now, 'phonenumbers offline metadata; not live carrier attribution'))
    flash('Local metadata enrichment saved. Caller ID may be spoofed.', 'success')
    return redirect(url_for('workspace'))


@app.route('/cases/<int:case_id>/integrity')
def integrity_page(case_id):
    with connect() as db:
        case = db.execute('SELECT * FROM cases WHERE id=?', (case_id,)).fetchone()
    if not case: abort(404)
    return render_template('integrity.html', case=case, results=evidence_integrity(case_id))


@app.route('/api/cases/<int:case_id>/integrity')
def integrity_json(case_id):
    from flask import jsonify
    with connect() as db:
        exists = db.execute('SELECT 1 FROM cases WHERE id=?', (case_id,)).fetchone()
    if not exists: abort(404)
    return jsonify({'case_id': case_id, 'results': evidence_integrity(case_id),
                    'checked_at': datetime.now(timezone.utc).isoformat()})


@app.route('/cases/<int:case_id>/contacts', methods=['GET', 'POST'])
def contacts_page(case_id):
    with connect() as db:
        case = db.execute('SELECT * FROM cases WHERE id=?', (case_id,)).fetchone()
        if not case: abort(404)
        if request.method == 'POST':
            from urllib.parse import urlsplit
            organization = request.form.get('organization','').strip()[:150]
            role = request.form.get('role','').strip()[:80]
            url = request.form.get('contact_url','').strip()[:1200]
            source = request.form.get('source_url','').strip()[:1200]
            note = request.form.get('verification_note','').strip()[:1200]
            if not organization or not role or not note or any(urlsplit(u).scheme != 'https' or not urlsplit(u).hostname or urlsplit(u).username or urlsplit(u).password for u in (url,source)):
                flash('Provide organization, role, HTTPS contact/source URLs and a verification note.', 'error')
                return redirect(url_for('contacts_page', case_id=case_id))
            db.execute('INSERT INTO abuse_contacts (case_id, organization, role, contact_url, source_url, verified_at, verification_note) VALUES (?,?,?,?,?,?,?)',
                       (case_id,organization,role,url,source,datetime.now(timezone.utc).isoformat(),note))
            return redirect(url_for('contacts_page', case_id=case_id))
        contacts = [dict(x) for x in db.execute('SELECT * FROM abuse_contacts WHERE case_id=? ORDER BY id DESC',(case_id,))]
    return render_template('contacts.html', case=case, contacts=contacts)


def analyze(raw):
    try:
        n = phonenumbers.parse(raw, 'US')
        if not phonenumbers.is_possible_number(n):
            return {'normalized': raw, 'valid': False, 'region': 'Unknown', 'carrier': 'Unknown', 'type': 'Unknown'}
        kinds = {PhoneNumberType.MOBILE: 'Mobile', PhoneNumberType.FIXED_LINE: 'Landline',
                 PhoneNumberType.FIXED_LINE_OR_MOBILE: 'Landline or mobile', PhoneNumberType.VOIP: 'VoIP',
                 PhoneNumberType.TOLL_FREE: 'Toll-free', PhoneNumberType.PREMIUM_RATE: 'Premium rate'}
        return {'normalized': phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.E164),
                'valid': phonenumbers.is_valid_number(n),
                'region': geocoder.description_for_number(n, 'en') or 'Unknown',
                'carrier': carrier.name_for_number(n, 'en') or 'Unknown',
                'type': kinds.get(number_type(n), 'Other / unknown')}
    except phonenumbers.NumberParseException:
        return {'normalized': raw, 'valid': False, 'region': 'Unknown', 'carrier': 'Unknown', 'type': 'Unknown'}


def rows():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM calls ORDER BY called_at DESC, id DESC')]


@app.route('/')
def index():
    calls = filtered_calls()
    counts = Counter(c['number'] for c in calls)
    return render_template('index.html', calls=calls, counts=counts,
                           total=len(calls), unique=len(counts), repeated=sum(v > 1 for v in counts.values()), filters=request.args)


@app.post('/add')
def add():
    raw = request.form.get('number', '').strip()[:60]
    timestamp = request.form.get('called_at', '').strip()
    if not raw or not timestamp:
        flash('Number and call time are required.', 'error')
        return redirect(url_for('index'))
    try:
        datetime.fromisoformat(timestamp)
    except ValueError:
        flash('Invalid call time.', 'error')
        return redirect(url_for('index'))
    info = analyze(raw)
    with connect() as db:
        db.execute('INSERT INTO calls (number, called_at, label, notes, source, created_at) VALUES (?,?,?,?,?,?)',
                   (info['normalized'], timestamp, request.form.get('label','')[:120],
                    request.form.get('notes','')[:2000], 'manual', datetime.now(timezone.utc).isoformat()))
    flash('Call recorded.', 'ok')
    return redirect(url_for('index'))


@app.post('/import')
def import_csv():
    f = request.files.get('file')
    if not f or not f.filename.lower().endswith('.csv'):
        flash('Upload a CSV file.', 'error')
        return redirect(url_for('index'))
    try:
        reader = csv.DictReader(io.StringIO(f.read().decode('utf-8-sig')))
        required = {'number', 'called_at'}
        if not required.issubset(set(reader.fieldnames or [])):
            raise ValueError('CSV must contain number and called_at columns')
        prepared = []
        for record in reader:
            raw = (record.get('number') or '').strip()[:60]
            stamp = (record.get('called_at') or '').strip()
            if not raw or not stamp:
                continue
            datetime.fromisoformat(stamp)
            prepared.append((analyze(raw)['normalized'], stamp, (record.get('label') or '')[:120],
                             (record.get('notes') or '')[:2000], 'csv', datetime.now(timezone.utc).isoformat()))
            if len(prepared) > 5000:
                raise ValueError('Maximum 5,000 rows per import')
        with connect() as db:
            db.executemany('INSERT INTO calls (number,called_at,label,notes,source,created_at) VALUES (?,?,?,?,?,?)', prepared)
        flash(f'Imported {len(prepared)} calls.', 'ok')
    except (ValueError, UnicodeError, csv.Error) as e:
        flash(f'Import failed: {e}', 'error')
    return redirect(url_for('index'))


@app.get('/lookup')
def lookup():
    number = request.args.get('number', '').strip()[:60]
    return render_template('lookup.html', number=number, info=analyze(number) if number else None)


@app.get('/report')
def report():
    calls = rows()
    counts = Counter(c['number'] for c in calls)
    return render_template('report.html', calls=calls, counts=counts,
                           generated=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'))


@app.get('/export.csv')
def export_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['number', 'called_at', 'label', 'notes', 'source'])
    for c in rows():
        writer.writerow([c[k] for k in ('number', 'called_at', 'label', 'notes', 'source')])
    return Response(output.getvalue(), mimetype='text/csv', headers={'Content-Disposition': 'attachment; filename=spam_call_evidence.csv'})


@app.post('/delete/<int:call_id>')
def delete(call_id):
    with connect() as db:
        db.execute('DELETE FROM calls WHERE id=?', (call_id,))
    return redirect(url_for('index'))




def campaign_key(label):
    """Conservative label-based grouping, not an attribution or identity claim."""
    tokens = re.findall(r'[a-z0-9]+', (label or '').lower())
    stop = {'the', 'from', 'call', 'caller', 'scam', 'spam', 'fake', 'unknown', 'said', 'claim', 'claimed', 'department'}
    tokens = [t for t in tokens if t not in stop and len(t) > 2]
    return ' '.join(sorted(set(tokens))[:5]) if tokens else ''


def build_graph():
    calls = rows()
    nodes, edges = {}, {}
    for c in calls:
        n = c['number']
        nodes['n:'+n] = {'id':'n:'+n, 'label':n, 'kind':'number'}
        key = campaign_key(c['label'])
        if key:
            cid = 'c:'+key
            nodes[cid] = {'id':cid, 'label':key, 'kind':'claim'}
            edges[('n:'+n, cid)] = {'source':'n:'+n, 'target':cid, 'kind':'shared claim'}
    with connect() as db:
        for r in db.execute('SELECT * FROM indicators ORDER BY id'):
            ind = dict(r)
            number_id = 'n:'+ind['number']
            nodes.setdefault(number_id, {'id':number_id,'label':ind['number'],'kind':'number'})
            ind_id = 'i:'+ind['kind']+':'+ind['value'].lower()
            nodes[ind_id] = {'id':ind_id,'label':ind['value'][:70], 'kind':'indicator'}
            edges[(number_id, ind_id)] = {'source':number_id,'target':ind_id,'kind':ind['kind']}
    with connect() as db:
        for r in db.execute('SELECT number,provider,assessment FROM reputation'):
            n='n:'+r['number']; p='r:'+r['provider'].lower()
            nodes.setdefault(n, {'id':n,'label':r['number'],'kind':'number'})
            nodes[p]={'id':p,'label':r['provider'],'kind':'reputation'}
            edges[(n,p)]={'source':n,'target':p,'kind':'reputation: '+r['assessment']}
    return {'nodes':list(nodes.values()), 'edges':list(edges.values())}


@app.get('/graph')
def graph():
    return render_template('graph.html')


@app.get('/api/graph')
def graph_data():
    return app.json.response(build_graph())


@app.get('/api/summary')
def summary_data():
    calls = rows()
    by_day = Counter(c['called_at'][:10] for c in calls)
    labels = defaultdict(set)
    for c in calls:
        key = campaign_key(c['label'])
        if key:
            labels[key].add(c['number'])
    campaigns = [{'claim_cluster':k, 'distinct_numbers':len(v), 'numbers':sorted(v)}
                 for k,v in labels.items() if len(v)>1]
    return app.json.response({'daily':[{'date':d,'calls':n} for d,n in sorted(by_day.items())],
                              'potential_claim_clusters':sorted(campaigns,key=lambda x:-x['distinct_numbers'])})


@app.post('/indicators')
def add_indicator():
    number = analyze(request.form.get('number','')[:60])['normalized']
    kind = request.form.get('kind','')
    value = request.form.get('value','').strip()[:200]
    source = request.form.get('source_url','').strip()[:500]
    confidence = request.form.get('confidence','unverified')
    if kind not in {'domain','url','claimed organization','other'} or not value or not number:
        abort(400)
    if source and not source.startswith(('https://','http://')):
        abort(400)
    if confidence not in {'unverified','corroborated'}:
        abort(400)
    with connect() as db:
        db.execute('INSERT INTO indicators (number,kind,value,source_url,confidence,created_at) VALUES (?,?,?,?,?,?)',
                   (number,kind,value,source,confidence,datetime.now(timezone.utc).isoformat()))
    flash('Indicator recorded. Association is not proof of attribution.', 'ok')
    return redirect(url_for('graph'))


@app.get('/api/indicators')
def indicators_data():
    with connect() as db:
        return app.json.response([dict(r) for r in db.execute('SELECT * FROM indicators ORDER BY id DESC')])


@app.post('/carrier-lookup')
def carrier_lookup():
    """Explicit opt-in API lookup; does not silently transmit phone numbers."""
    raw = request.form.get('number','').strip()[:60]
    info = analyze(raw)
    if not info['valid']:
        flash('Enter a valid number before requesting a lookup.', 'error')
        return redirect(url_for('lookup',number=raw))
    sid, token = os.environ.get('TWILIO_ACCOUNT_SID'), os.environ.get('TWILIO_AUTH_TOKEN')
    if not sid or not token:
        flash('Twilio API is not configured. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN.', 'error')
        return redirect(url_for('lookup',number=raw))
    encoded = urllib.parse.quote(info['normalized'], safe='')
    url = f'https://lookups.twilio.com/v2/PhoneNumbers/{encoded}?Fields=line_type_intelligence'
    auth = base64.b64encode((sid+':'+token).encode()).decode()
    req = urllib.request.Request(url,headers={'Authorization':'Basic '+auth, 'Accept':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=10) as response:
            data = json.load(response)
        details = data.get('line_type_intelligence') or {}
        result = {'number':info['normalized'], 'carrier':details.get('carrier_name') or 'Unknown',
                  'type':details.get('type') or 'Unknown', 'error_code':details.get('error_code')}
        with connect() as db:
            db.execute('INSERT INTO provider_checks(number,provider,carrier,line_type,checked_at) VALUES(?,?,?,?,?)', (result['number'],'Twilio Lookup',result['carrier'],result['type'],datetime.now(timezone.utc).isoformat()))
        return render_template('carrier.html', result=result)
    except Exception:
        flash('Lookup failed. Check credentials, connectivity, account permissions and API billing.', 'error')
        return redirect(url_for('lookup',number=raw))


@app.get('/export.json')
def export_json():
    with connect() as db:
        indicators = [dict(r) for r in db.execute('SELECT * FROM indicators ORDER BY id')]
    with connect() as db:
        reputation = [dict(r) for r in db.execute('SELECT * FROM reputation ORDER BY id')]
    payload = {'reputation':reputation, 'generated_utc':datetime.now(timezone.utc).isoformat(), 'calls':rows(),
               'indicators':indicators, 'graph':build_graph(),
               'disclaimer':'Caller ID may be spoofed. Associations are investigative leads, not attribution.'}
    return Response(json.dumps(payload,indent=2),mimetype='application/json',
                    headers={'Content-Disposition':'attachment; filename=callerrecon_evidence.json'})




def filtered_calls():
    query = 'SELECT * FROM calls WHERE 1=1'
    params = []
    for key, sql in [('number','number LIKE ?'),('label','label LIKE ?')]:
        value = request.args.get(key,'').strip()[:100]
        if value:
            query += ' AND ' + sql
            params.append('%'+value+'%')
    start = request.args.get('start','')[:16]
    end = request.args.get('end','')[:16]
    if start:
        try: datetime.fromisoformat(start)
        except ValueError: abort(400)
        query += ' AND called_at >= ?'; params.append(start)
    if end:
        try: datetime.fromisoformat(end)
        except ValueError: abort(400)
        query += ' AND called_at <= ?'; params.append(end)
    query += ' ORDER BY called_at DESC, id DESC LIMIT 10000'
    with connect() as db:
        return [dict(r) for r in db.execute(query,params)]

@app.get('/cases')
def cases_page():
    with connect() as db:
        cases=[dict(r) for r in db.execute('SELECT c.*, COUNT(cc.call_id) AS call_count FROM cases c LEFT JOIN case_calls cc ON c.id=cc.case_id GROUP BY c.id ORDER BY c.id DESC')]
    return render_template('cases.html',cases=cases)

@app.post('/cases')
def create_case():
    title=request.form.get('title','').strip()[:150]
    if not title: abort(400)
    with connect() as db:
        cur=db.execute('INSERT INTO cases(title,description,created_at) VALUES (?,?,?)',(title,request.form.get('description','')[:3000],datetime.now(timezone.utc).isoformat()))
        case_id=cur.lastrowid
    return redirect(url_for('case_detail',case_id=case_id))

@app.get('/cases/<int:case_id>')
def case_detail(case_id):
    with connect() as db:
        case=db.execute('SELECT * FROM cases WHERE id=?',(case_id,)).fetchone()
        if not case: abort(404)
        linked=[dict(r) for r in db.execute('SELECT calls.* FROM calls JOIN case_calls ON calls.id=case_calls.call_id WHERE case_calls.case_id=? ORDER BY called_at DESC',(case_id,))]
        available=[dict(r) for r in db.execute('SELECT id,number,called_at,label FROM calls WHERE id NOT IN (SELECT call_id FROM case_calls WHERE case_id=?) ORDER BY called_at DESC LIMIT 300',(case_id,))]
        attachments=[dict(r) for r in db.execute('SELECT * FROM attachments WHERE case_id=? ORDER BY id DESC',(case_id,))]
    return render_template('case_detail.html',case=dict(case),linked=linked,available=available,attachments=attachments)

@app.post('/cases/<int:case_id>/status')
def case_status(case_id):
    status=request.form.get('status')
    if status not in {'open','review','closed'}: abort(400)
    with connect() as db:
        db.execute('UPDATE cases SET status=? WHERE id=?',(status,case_id))
    return redirect(url_for('case_detail',case_id=case_id))

@app.post('/cases/<int:case_id>/calls')
def link_call(case_id):
    try: call_id=int(request.form.get('call_id',''))
    except ValueError: abort(400)
    with connect() as db:
        if not db.execute('SELECT 1 FROM cases WHERE id=?',(case_id,)).fetchone() or not db.execute('SELECT 1 FROM calls WHERE id=?',(call_id,)).fetchone(): abort(404)
        db.execute('INSERT OR IGNORE INTO case_calls(case_id,call_id) VALUES (?,?)',(case_id,call_id))
    return redirect(url_for('case_detail',case_id=case_id))

@app.post('/cases/<int:case_id>/attachments')
def upload_attachment(case_id):
    with connect() as db:
        if not db.execute('SELECT 1 FROM cases WHERE id=?',(case_id,)).fetchone(): abort(404)
    f=request.files.get('file')
    if not f or not f.filename: abort(400)
    name=Path(f.filename.replace('\\','/')).name[:180]
    ext=Path(name).suffix.lower()
    if ext not in ALLOWED_EXT: abort(400,'Unsupported evidence file type')
    data=f.read()
    if not data or len(data)>7*1024*1024: abort(400,'Evidence must be 1 byte to 7 MB')
    digest=hashlib.sha256(data).hexdigest()
    stored=secrets.token_hex(20)+ext
    path=EVIDENCE_DIR/stored
    with open(path,'xb') as output: output.write(data)
    with connect() as db:
        db.execute('INSERT INTO attachments(case_id,original_name,stored_name,sha256,size,created_at) VALUES (?,?,?,?,?,?)',(case_id,name,stored,digest,len(data),datetime.now(timezone.utc).isoformat()))
    return redirect(url_for('case_detail',case_id=case_id))

@app.get('/evidence/<int:attachment_id>')
def evidence_download(attachment_id):
    with connect() as db:
        r=db.execute('SELECT * FROM attachments WHERE id=?',(attachment_id,)).fetchone()
    if not r: abort(404)
    return send_file(EVIDENCE_DIR/r['stored_name'],as_attachment=True,download_name=r['original_name'],mimetype='application/octet-stream')

@app.get('/cases/<int:case_id>/report')
def case_report(case_id):
    with connect() as db:
        case=db.execute('SELECT * FROM cases WHERE id=?',(case_id,)).fetchone()
        if not case: abort(404)
        calls=[dict(r) for r in db.execute('SELECT calls.* FROM calls JOIN case_calls ON calls.id=case_calls.call_id WHERE case_id=? ORDER BY called_at DESC',(case_id,))]
        attachments=[dict(r) for r in db.execute('SELECT original_name,sha256,size,created_at FROM attachments WHERE case_id=?',(case_id,))]
    return render_template('case_report.html',case=dict(case),calls=calls,attachments=attachments,generated=datetime.now(timezone.utc).isoformat())


# v1.3: Reputation is manually entered from lawful public or licensed sources.
# No unlicensed scraping, hidden queries, or unconsented number submission.
@app.get('/intelligence')
def intelligence_page():
    with connect() as db:
        entries=[dict(r) for r in db.execute('SELECT * FROM reputation ORDER BY id DESC LIMIT 500')]
    return render_template('intelligence.html', entries=entries, scores=score_numbers())

@app.post('/reputation')
def add_reputation():
    raw=request.form.get('number','').strip()[:60]
    number=analyze(raw)['normalized']
    provider=request.form.get('provider','').strip()[:100]
    assessment=request.form.get('assessment','').strip()
    url=request.form.get('source_url','').strip()[:500]
    notes=request.form.get('notes','').strip()[:1000]
    if not raw or not provider or assessment not in {'spam','suspected scam','unknown','not spam'}: abort(400)
    if url and not url.startswith(('https://','http://')): abort(400)
    count=request.form.get('report_count','').strip()
    if count:
        try: count=int(count)
        except ValueError: abort(400)
        if count<0 or count>100000000: abort(400)
    else: count=None
    with connect() as db:
        db.execute('INSERT INTO reputation(number,provider,assessment,report_count,source_url,notes,checked_at) VALUES (?,?,?,?,?,?,?)',
                   (number,provider,assessment,count,url,notes,datetime.now(timezone.utc).isoformat()))
    return redirect(url_for('intelligence_page'))

def score_numbers():
    """Explainable investigative priority, NOT scam probability or perpetrator attribution."""
    calls=rows()
    grouped=defaultdict(list)
    for c in calls: grouped[c['number']].append(c)
    with connect() as db:
        rep=defaultdict(list)
        for r in db.execute('SELECT * FROM reputation'): rep[r['number']].append(dict(r))
        ind=defaultdict(list)
        for r in db.execute('SELECT * FROM indicators'): ind[r['number']].append(dict(r))
    results=[]
    for number in sorted(set(grouped)|set(rep)|set(ind)):
        evidence=[]; score=0
        n=len(grouped[number])
        if n>=3: score+=20; evidence.append('3+ recorded calls (+20)')
        elif n>=2: score+=10; evidence.append('Repeated calls (+10)')
        positives={r['provider'].casefold() for r in rep[number] if r['assessment'] in {'spam','suspected scam'}}
        if positives: score+=min(40,20*len(positives)); evidence.append(f'{len(positives)} independent named reputation source(s) (+{min(40,20*len(positives))})')
        verified=sum(r['confidence']=='corroborated' for r in ind[number])
        if verified: score+=min(20,10*verified); evidence.append(f'{verified} corroborated indicator(s) (+{min(20,10*verified)})')
        keys={campaign_key(c['label']) for c in grouped[number]}-{''}
        if keys:
            peers={c['number'] for c in calls if c['number']!=number and campaign_key(c['label']) in keys}
            if peers: score+=10; evidence.append('Shared claim text across displayed numbers (+10)')
        results.append({'number':number,'score':min(100,score),'reasons':evidence,'calls':n,'reputation':len(rep[number]),'indicators':len(ind[number])})
    return sorted(results,key=lambda r:(-r['score'],-r['calls'],r['number']))

@app.get('/api/intelligence')
def intelligence_api():
    return app.json.response({'method':'heuristic evidence-priority score; not probability or attribution','numbers':score_numbers()})


# v1.4: analyst-controlled transcripts and case intelligence. No external audio transfer.
@app.get('/threat-dashboard')
def threat_dashboard():
    with connect() as db:
        cases=[dict(r) for r in db.execute('SELECT * FROM cases ORDER BY id DESC')]
        checks=[dict(r) for r in db.execute('SELECT * FROM provider_checks ORDER BY id DESC LIMIT 25')]
        transcripts=[dict(r) for r in db.execute('SELECT * FROM transcripts ORDER BY id DESC LIMIT 25')]
    call_rows=rows()
    timeline=Counter(c['called_at'][:10] for c in call_rows)
    clusters=defaultdict(lambda:{'numbers':set(),'calls':0})
    for c in call_rows:
        key=campaign_key(c['label'])
        if key:
            clusters[key]['numbers'].add(c['number']); clusters[key]['calls']+=1
    campaigns=[{'claim':k,'numbers':len(v['numbers']),'calls':v['calls']} for k,v in clusters.items() if len(v['numbers'])>1]
    campaigns.sort(key=lambda x:(-x['numbers'],-x['calls']))
    return render_template('threat_dashboard.html',cases=cases,checks=checks,transcripts=transcripts,
                           scores=score_numbers()[:20], campaigns=campaigns[:20],
                           timeline=sorted(timeline.items()),total=len(call_rows),unique=len(set(c['number'] for c in call_rows)))

@app.get('/api/campaigns')
def campaign_api():
    calls=rows(); grouped=defaultdict(lambda:{'numbers':set(),'calls':0})
    for c in calls:
        key=campaign_key(c['label'])
        if key:
            grouped[key]['numbers'].add(c['number']);grouped[key]['calls']+=1
    return app.json.response({'disclaimer':'Shared claim wording is not proof of a common caller or identity.',
      'campaigns':[{'claim':k,'displayed_numbers':len(v['numbers']),'call_count':v['calls']} for k,v in grouped.items() if len(v['numbers'])>1]})

@app.post('/cases/<int:case_id>/transcripts')
def add_transcript(case_id):
    transcript=request.form.get('transcript','').strip()
    if not transcript or len(transcript)>100000: abort(400)
    with connect() as db:
        if not db.execute('SELECT id FROM cases WHERE id=?',(case_id,)).fetchone():abort(404)
        db.execute('INSERT INTO transcripts(case_id,attachment_id,transcript,engine,created_at) VALUES(?,?,?,?,?)',
                   (case_id,None,transcript,'analyst supplied',datetime.now(timezone.utc).isoformat()))
    return redirect(url_for('case_detail',case_id=case_id))

@app.post('/cases/<int:case_id>/transcribe/<int:attachment_id>')
def transcribe_attachment(case_id,attachment_id):
    with connect() as db:
        a=db.execute('SELECT * FROM attachments WHERE id=? AND case_id=?',(attachment_id,case_id)).fetchone()
        if not a:abort(404)
        a=dict(a)
    if Path(a['original_name']).suffix.lower() not in {'.wav','.mp3','.m4a'}:abort(400)
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        flash('Offline transcription is optional: pip install faster-whisper.','error')
        return redirect(url_for('case_detail',case_id=case_id))
    model_name=os.environ.get('CALLERRECON_WHISPER_MODEL','tiny.en')
    if model_name not in {'tiny.en','base.en','small.en'}:abort(400)
    try:
        model=WhisperModel(model_name,device='cpu',compute_type='int8')
        segments,_=model.transcribe(str(EVIDENCE_DIR/a['stored_name']),beam_size=1)
        transcript=' '.join(seg.text.strip() for seg in segments)[:100000]
    except Exception:
        flash('Offline transcription failed; verify audio codec and local model availability.','error')
        return redirect(url_for('case_detail',case_id=case_id))
    with connect() as db:
        db.execute('INSERT INTO transcripts(case_id,attachment_id,transcript,engine,created_at) VALUES(?,?,?,?,?)',
                   (case_id,attachment_id,transcript,'faster-whisper '+model_name,datetime.now(timezone.utc).isoformat()))
    flash('Local transcription saved. Review accuracy before citing.','success')
    return redirect(url_for('case_detail',case_id=case_id))

@app.get('/cases/<int:case_id>/intelligence.json')
def case_intelligence(case_id):
    with connect() as db:
        case=db.execute('SELECT * FROM cases WHERE id=?',(case_id,)).fetchone()
        if not case:abort(404)
        calls=[dict(r) for r in db.execute('SELECT calls.* FROM calls JOIN case_calls ON calls.id=case_calls.call_id WHERE case_id=?',(case_id,))]
        evidence=[dict(r) for r in db.execute('SELECT original_name,sha256,size,created_at FROM attachments WHERE case_id=?',(case_id,))]
        transcripts=[dict(r) for r in db.execute('SELECT transcript,engine,created_at FROM transcripts WHERE case_id=?',(case_id,))]
    scores={x['number']:x for x in score_numbers()}
    return app.json.response({'case':dict(case),'calls':calls,'attachments':evidence,'transcripts':transcripts,
      'priority_scores':[scores[n] for n in set(c['number'] for c in calls) if n in scores],
      'limitations':['Displayed caller ID may be spoofed','Scores are investigative priorities, not scam probabilities','No attribution of real-world identity']})



# v1.5 lawful countermeasures: passive, analyst-controlled, no automated takedowns.
REPORT_TARGETS = {
 'fcc': ('FCC unwanted calls complaint', 'https://consumercomplaints.fcc.gov/'),
 'ftc': ('FTC ReportFraud', 'https://reportfraud.ftc.gov/'),
 'donotcall': ('FTC Do Not Call complaint', 'https://www.donotcall.gov/'),
 'ic3': ('FBI IC3 cyber-enabled fraud report', 'https://www.ic3.gov/'),
 'provider': ('Telecommunications provider abuse desk', ''),
 'registrar': ('Domain registrar abuse desk', '')
}

def countermeasure_tables():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS osint_findings (
          id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
          kind TEXT NOT NULL, indicator TEXT NOT NULL, source_url TEXT NOT NULL DEFAULT '',
          observation TEXT NOT NULL, confidence TEXT NOT NULL, observed_at TEXT NOT NULL,
          recorded_at TEXT NOT NULL, FOREIGN KEY(case_id) REFERENCES cases(id))""")
        db.execute("""CREATE TABLE IF NOT EXISTS abuse_reports (
          id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
          destination TEXT NOT NULL, recipient TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT 'draft', reference TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(case_id) REFERENCES cases(id))""")
        db.execute("""CREATE TABLE IF NOT EXISTS evidence_events (
          id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
          attachment_id INTEGER, action TEXT NOT NULL, actor TEXT NOT NULL,
          details TEXT NOT NULL, recorded_at TEXT NOT NULL,
          FOREIGN KEY(case_id) REFERENCES cases(id))""")

countermeasure_tables()

def case_exists(case_id):
    with connect() as db:
        if not db.execute('SELECT id FROM cases WHERE id=?',(case_id,)).fetchone(): abort(404)

def utc_now(): return datetime.now(timezone.utc).isoformat()

def validate_url(url):
    if not url: return True
    parsed=urllib.parse.urlsplit(url)
    return parsed.scheme in ('https','http') and bool(parsed.hostname) and not parsed.username and not parsed.password

def case_bundle(case_id):
    with connect() as db:
        case=db.execute('SELECT * FROM cases WHERE id=?',(case_id,)).fetchone()
        if not case: abort(404)
        def fetch(q):return [dict(r) for r in db.execute(q,(case_id,))]
        return {'case':dict(case),
         'calls':fetch('SELECT calls.* FROM calls JOIN case_calls cc ON cc.call_id=calls.id WHERE cc.case_id=? ORDER BY called_at'),
         'findings':fetch('SELECT * FROM osint_findings WHERE case_id=? ORDER BY id'),
         'reports':fetch('SELECT * FROM abuse_reports WHERE case_id=? ORDER BY id'),
         'attachments':fetch('SELECT id,original_name,sha256,size,created_at FROM attachments WHERE case_id=? ORDER BY id'),
         'events':fetch('SELECT * FROM evidence_events WHERE case_id=? ORDER BY id'),
         'transcripts':fetch('SELECT id,attachment_id,transcript,engine,created_at FROM transcripts WHERE case_id=? ORDER BY id')}

@app.get('/countermeasures')
def countermeasures_home():
    with connect() as db:
        cases=[dict(r) for r in db.execute('SELECT id,title,status FROM cases ORDER BY id DESC')]
    return render_template('countermeasures.html',cases=cases)

@app.get('/cases/<int:case_id>/countermeasures')
def countermeasures_case(case_id):
    return render_template('countermeasure_case.html', bundle=case_bundle(case_id),targets=REPORT_TARGETS)

@app.post('/cases/<int:case_id>/findings')
def record_finding(case_id):
    case_exists(case_id)
    kind=request.form.get('kind','')
    confidence=request.form.get('confidence','')
    indicator=request.form.get('indicator','').strip()[:300]
    observation=request.form.get('observation','').strip()[:4000]
    source=request.form.get('source_url','').strip()[:1000]
    observed=request.form.get('observed_at','').strip()
    if kind not in {'phone','domain','url','claimed identity','provider','public report','other'} or confidence not in {'unverified','single source','corroborated'} or not indicator or not observation or not validate_url(source): abort(400)
    try: datetime.fromisoformat(observed)
    except ValueError: abort(400)
    with connect() as db:
        db.execute('INSERT INTO osint_findings(case_id,kind,indicator,source_url,observation,confidence,observed_at,recorded_at) VALUES (?,?,?,?,?,?,?,?)',
            (case_id,kind,indicator,source,observation,confidence,observed,utc_now()))
    return redirect(url_for('countermeasures_case',case_id=case_id))

@app.post('/cases/<int:case_id>/abuse-reports')
def create_abuse_report(case_id):
    case_exists(case_id)
    destination=request.form.get('destination','')
    if destination not in REPORT_TARGETS: abort(400)
    recipient=request.form.get('recipient','').strip()[:300]
    notes=request.form.get('notes','').strip()[:3000]
    if destination in {'provider','registrar'} and not recipient: abort(400)
    now=utc_now()
    with connect() as db:
        db.execute('INSERT INTO abuse_reports(case_id,destination,recipient,notes,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                   (case_id,destination,recipient,notes,now,now))
    return redirect(url_for('countermeasures_case',case_id=case_id))

@app.post('/cases/<int:case_id>/abuse-reports/<int:report_id>/status')
def report_status(case_id,report_id):
    case_exists(case_id)
    status=request.form.get('status','')
    if status not in {'draft','submitted','acknowledged','resolved','closed'}: abort(400)
    with connect() as db:
        cur=db.execute('UPDATE abuse_reports SET status=?,reference=?,updated_at=? WHERE id=? AND case_id=?',
                       (status,request.form.get('reference','').strip()[:250],utc_now(),report_id,case_id))
        if not cur.rowcount: abort(404)
    return redirect(url_for('countermeasures_case',case_id=case_id))

@app.post('/cases/<int:case_id>/evidence-events')
def evidence_event(case_id):
    case_exists(case_id)
    action=request.form.get('action','')
    if action not in {'collected','transferred','verified','reviewed','preserved','other'}: abort(400)
    actor=request.form.get('actor','').strip()[:120]
    details=request.form.get('details','').strip()[:3000]
    attachment=request.form.get('attachment_id','').strip()
    if not actor or not details: abort(400)
    aid=None
    with connect() as db:
        if attachment:
            try: aid=int(attachment)
            except ValueError: abort(400)
            if not db.execute('SELECT id FROM attachments WHERE id=? AND case_id=?',(aid,case_id)).fetchone():abort(400)
        db.execute('INSERT INTO evidence_events(case_id,attachment_id,action,actor,details,recorded_at) VALUES(?,?,?,?,?,?)',
                   (case_id,aid,action,actor,details,utc_now()))
    return redirect(url_for('countermeasures_case',case_id=case_id))

@app.get('/cases/<int:case_id>/countermeasures.json')
def countermeasures_json(case_id):
    bundle=case_bundle(case_id)
    bundle['exported_at']=utc_now()
    bundle['limitations']=['Caller ID may be spoofed; no real-world identity attribution','Analyst findings require independent verification','This export is not a legal determination','Evidence hash only validates file bytes against a known digest']
    payload=json.dumps(bundle,indent=2,ensure_ascii=False)
    return Response(payload,mimetype='application/json',headers={'Content-Disposition':f'attachment; filename=callerrecon-case-{case_id}.json'})

@app.get('/cases/<int:case_id>/abuse-reports/<int:report_id>/draft')
def abuse_draft(case_id,report_id):
    bundle=case_bundle(case_id)
    report=next((r for r in bundle['reports'] if r['id']==report_id),None)
    if not report: abort(404)
    title,url=REPORT_TARGETS[report['destination']]
    return render_template('abuse_draft.html',bundle=bundle,report=report,title=title,target_url=url,generated=utc_now())

@app.get('/cases/<int:case_id>/countermeasures-report')
def countermeasures_report(case_id):
    return render_template('countermeasure_report.html',bundle=case_bundle(case_id),generated=utc_now())


# v1.7: analyst-controlled graph filtering, local transcript indicators, SOC workspace.
TRANSCRIPT_PATTERNS = {
    'urgency': r'\b(?:urgent|immediately|final notice|last chance|act now|arrest warrant)\b',
    'payment request': r'\b(?:gift card|wire transfer|bitcoin|cryptocurrency|payment|bank account)\b',
    'credential request': r'\b(?:password|verification code|one.time code|social security number|ssn|pin number)\b',
    'remote access': r'\b(?:remote access|anydesk|teamviewer|install software|screen sharing)\b',
    'impersonation': r'\b(?:irs|social security administration|microsoft support|police department|amazon support)\b',
}

def transcript_signals(content):
    text = content or ''
    findings = []
    for category, pattern in TRANSCRIPT_PATTERNS.items():
        matches = list(re.finditer(pattern, text, re.IGNORECASE))
        if matches:
            findings.append({'category':category,'count':len(matches),
                             'examples':list(dict.fromkeys(m.group(0) for m in matches))[:5]})
    return findings

@app.get('/api/v17/graph')
def graph_filtered():
    graph = build_graph()
    kind = request.args.get('kind','all')
    query = request.args.get('q','').strip().casefold()[:100]
    if kind not in {'all','number','claim','indicator','reputation'}: abort(400)
    nodes = graph['nodes']
    if kind != 'all': nodes = [n for n in nodes if n['kind']==kind]
    if query:
        # Include direct neighbors for context, but do not imply identity.
        matches = {n['id'] for n in nodes if query in n['label'].casefold()}
        if kind == 'all':
            matches |= {e['target'] for e in graph['edges'] if e['source'] in matches}
            matches |= {e['source'] for e in graph['edges'] if e['target'] in matches}
        nodes = [n for n in nodes if n['id'] in matches]
    allowed = {n['id'] for n in nodes}
    edges = [e for e in graph['edges'] if e['source'] in allowed and e['target'] in allowed]
    return app.json.response({'nodes':nodes,'edges':edges,
      'disclaimer':'Correlations are investigative leads, not attribution. Displayed caller ID may be spoofed.'})

@app.get('/api/v17/cases/<int:case_id>/transcript-signals')
def transcript_signals_api(case_id):
    with connect() as db:
        if not db.execute('SELECT id FROM cases WHERE id=?',(case_id,)).fetchone():abort(404)
        transcripts = [dict(r) for r in db.execute(
          'SELECT id,transcript,engine,created_at FROM transcripts WHERE case_id=? ORDER BY id',(case_id,))]
    return app.json.response({'case_id':case_id,'analyses':[
      {'transcript_id':t['id'],'engine':t['engine'],'created_at':t['created_at'],
       'signals':transcript_signals(t['transcript'])} for t in transcripts],
       'limitations':'Keyword flags are heuristic and require human review; transcripts may be inaccurate.'})

@app.get('/soc')
def soc_dashboard():
    with connect() as db:
        cases = [dict(r) for r in db.execute('SELECT id,title,status,created_at FROM cases ORDER BY id DESC LIMIT 30')]
        transcripts = [dict(r) for r in db.execute('SELECT id,case_id,transcript FROM transcripts ORDER BY id DESC LIMIT 100')]
        report_count = db.execute('SELECT COUNT(*) FROM abuse_reports').fetchone()[0]
        attachment_count = db.execute('SELECT COUNT(*) FROM attachments').fetchone()[0]
    calls = rows()
    days = Counter(c['called_at'][:10] for c in calls)
    signals = Counter(sig['category'] for t in transcripts for sig in transcript_signals(t['transcript']))
    return render_template('soc.html',cases=cases,total_calls=len(calls),
      unique_numbers=len(set(c['number'] for c in calls)),reports=report_count,
      evidence=attachment_count,days=sorted(days.items())[-30:],signals=signals.most_common(),
      top_numbers=Counter(c['number'] for c in calls).most_common(10))

@app.get('/api/v17/health')
def v17_health():
    return app.json.response({'version':'1.7','mode':'local passive intelligence',
      'integrations':{'twilio':'optional; existing carrier lookup route',
                      'transcription':'optional local faster-whisper',
                      'reputation':'analyst-supplied evidence only'}})

init_db()
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5050, debug=False)
